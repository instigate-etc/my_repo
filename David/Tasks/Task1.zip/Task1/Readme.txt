This is a program which calculates the multipling of four elements which are ordered by left by down and by two diagonals of an two dimentional array. Determines the maximum value from multipling results and prints it.
the array has 20 20 size.
for running program we must execute this comands.

javac ReadArray.java
javac Main.java
java Main input.txt

input.txt is a file which contains the array.